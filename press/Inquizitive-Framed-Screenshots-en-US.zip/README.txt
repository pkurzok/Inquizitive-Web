Inquizitive: Smart AI Quiz. Press screenshots (en-US)
https://inquizitive.peterkurzok.de/press/

Image usage: please use these screenshots and the app icon only in coverage of Inquizitive. The
device frames in the framed set (iPhone, iPad, MacBook Pro) are Apple's product bezel artwork,
licensed under the Apple Design Resources licence: it may not be extracted, modified, redistributed
or repackaged. The Vision Pro screenshots are unframed.

Screenshots in the other 16 app languages are available on request: inquizitive@peterkurzok.de
